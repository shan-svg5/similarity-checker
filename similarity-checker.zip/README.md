# Similarity Report Checker

A comprehensive system for students to upload assignments and similarity reports, with automatic similarity percentage extraction and resubmission workflows.

## Features

### Student Panel
- Upload DOCX, PPTX, and similarity report files
- Automatic similarity percentage extraction from reports
- Forced resubmission if similarity > 10%
- View submission history with status tracking
- File download links for all submissions

### Faculty Panel
- View all student submissions with version history
- Filter submissions by student
- Download all submitted files
- Track similarity percentages and acceptance status
- Timestamp tracking for all submissions

## Tech Stack

### Backend
- **Django 4.2** with Django REST Framework
- **JWT Authentication** using SimpleJWT
- **File Upload** handling with local storage
- **Similarity Extraction** using python-docx and PyPDF2
- **SQLite** database for development

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **shadcn/ui** components
- **Axios** for API communication
- **React Router** for navigation

## Setup Instructions

### Backend Setup

1. **Create virtual environment:**
   \`\`\`bash
   cd backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   \`\`\`

2. **Install dependencies:**
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

3. **Run migrations:**
   \`\`\`bash
   python manage.py makemigrations
   python manage.py migrate
   \`\`\`

4. **Create demo users:**
   \`\`\`bash
   python create_demo_users.py
   \`\`\`

5. **Start the development server:**
   \`\`\`bash
   python manage.py runserver
   \`\`\`

### Frontend Setup

1. **Install dependencies:**
   \`\`\`bash
   cd frontend
   npm install
   \`\`\`

2. **Start the development server:**
   \`\`\`bash
   npm start
   \`\`\`

The application will be available at:
- Frontend: http://localhost:3000
- Backend API: http://localhost:8000

## Demo Credentials

### Faculty Login
- **Username:** faculty1
- **Password:** faculty123

### Student Logins
- **Student 1:** username: student1, password: student123
- **Student 2:** username: student2, password: student123

## API Endpoints

### Authentication
- `POST /api/auth/login/` - User login
- `POST /api/auth/logout/` - User logout
- `GET /api/auth/profile/` - Get user profile

### Submissions
- `POST /api/submissions/create/` - Create new submission (Students)
- `GET /api/submissions/student/` - Get student's submissions
- `GET /api/submissions/faculty/` - Get all submissions (Faculty)
- `GET /api/students/` - Get list of students (Faculty)

## Testing Flow

1. **Student Login:** Use student1 credentials to log in
2. **File Upload:** Upload DOCX, PPTX, and a similarity report with >10% similarity
3. **Rejection:** System should reject and request resubmission
4. **Resubmission:** Upload new files with <10% similarity
5. **Acceptance:** System should accept the submission
6. **Faculty View:** Login as faculty1 to view all submissions with version history

## Similarity Report Format

The system can extract similarity percentages from various formats:
- PDF files using PyPDF2
- DOCX files using python-docx
- Text files with common similarity report patterns

Supported patterns include:
- "Similarity: 15%"
- "15% similarity"
- "Overall similarity: 15%"
- "Plagiarism: 15%"
- And many other common formats

## File Structure

\`\`\`
similarity-checker/
├── backend/
│   ├── similarity_checker/
│   │   ├── settings.py
│   │   ├── urls.py
│   │   └── wsgi.py
│   ├── submissions/
│   │   ├── models.py
│   │   ├── views.py
│   │   ├── serializers.py
│   │   ├── urls.py
│   │   └── utils.py
│   ├── manage.py
│   ├── create_demo_users.py
│   └── requirements.txt
└── frontend/
    ├── src/
    │   ├── components/
    │   │   ├── Login.tsx
    │   │   ├── StudentDashboard.tsx
    │   │   └── FacultyDashboard.tsx
    │   ├── contexts/
    │   │   └── AuthContext.tsx
    │   ├── services/
    │   │   └── api.ts
    │   ├── App.tsx
    │   └── index.tsx
    ├── package.json
    └── tsconfig.json
\`\`\`

## Key Features Implementation

### Similarity Extraction
The system uses regex patterns to extract similarity percentages from uploaded reports. It supports multiple file formats and common similarity report patterns.

### Version Control
Each resubmission creates a new version while retaining previous submissions for faculty review.

### Role-Based Access
- Students can only view their own submissions
- Faculty can view all student submissions
- Proper authentication and authorization implemented

### File Management
- Secure file upload handling
- Organized file storage structure
- Direct download links for faculty

## Troubleshooting

### Common Issues

1. **CORS Errors:** Ensure Django CORS settings are properly configured
2. **File Upload Issues:** Check file size limits and permissions
3. **Authentication Issues:** Verify JWT token configuration
4. **Database Issues:** Run migrations if models are updated

### Development Tips

1. Use Django admin panel for user management: http://localhost:8000/admin/
2. Check browser console for frontend errors
3. Monitor Django logs for backend issues
4. Test API endpoints using tools like Postman

This system provides a complete solution for similarity report checking with proper user management, file handling, and workflow automation.
