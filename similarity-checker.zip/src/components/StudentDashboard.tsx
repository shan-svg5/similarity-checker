"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useAuth } from "../contexts/AuthContext"
import api from "../services/api"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { LogOut, Upload, FileText, Presentation, BarChart3, CheckCircle, XCircle, Clock } from "lucide-react"

interface Submission {
  id: number
  docx_file: string
  pptx_file: string
  similarity_report: string
  similarity_percentage: number
  is_accepted: boolean
  version: number
  created_at: string
}

const StudentDashboard: React.FC = () => {
  const { user, logout } = useAuth()
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")

  const [docxFile, setDocxFile] = useState<File | null>(null)
  const [pptxFile, setPptxFile] = useState<File | null>(null)
  const [reportFile, setReportFile] = useState<File | null>(null)

  useEffect(() => {
    fetchSubmissions()
  }, [])

  const fetchSubmissions = async () => {
    setLoading(true)
    try {
      const response = await api.get("/submissions/student/")
      setSubmissions(response.data)
    } catch (error) {
      console.error("Error fetching submissions:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!docxFile || !pptxFile || !reportFile) {
      setError("Please select all three files")
      return
    }

    setUploading(true)

    const formData = new FormData()
    formData.append("docx_file", docxFile)
    formData.append("pptx_file", pptxFile)
    formData.append("similarity_report", reportFile)

    try {
      await api.post("/submissions/create/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })

      setSuccess("Files uploaded successfully!")
      setDocxFile(null)
      setPptxFile(null)
      setReportFile(null)

      // Reset file inputs
      const fileInputs = document.querySelectorAll('input[type="file"]') as NodeListOf<HTMLInputElement>
      fileInputs.forEach((input) => (input.value = ""))

      // Refresh submissions
      await fetchSubmissions()
    } catch (error: any) {
      setError(error.response?.data?.detail || "Upload failed")
    } finally {
      setUploading(false)
    }
  }

  const getStatusBadge = (submission: Submission) => {
    if (submission.similarity_percentage === null) {
      return (
        <Badge variant="secondary">
          <Clock className="w-3 h-3 mr-1" />
          Processing
        </Badge>
      )
    }

    if (submission.is_accepted) {
      return (
        <Badge variant="default" className="bg-green-500">
          <CheckCircle className="w-3 h-3 mr-1" />
          Accepted
        </Badge>
      )
    } else {
      return (
        <Badge variant="destructive">
          <XCircle className="w-3 h-3 mr-1" />
          Rejected
        </Badge>
      )
    }
  }

  const latestSubmission = submissions[0]
  const canSubmit = !latestSubmission || latestSubmission.is_accepted || latestSubmission.similarity_percentage === null

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Student Dashboard</h1>
              <p className="text-gray-600">
                Welcome, {user?.first_name} {user?.last_name}
              </p>
            </div>
            <Button onClick={logout} variant="outline">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Upload Form */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Upload className="w-5 h-5 mr-2" />
                  Upload Submission
                </CardTitle>
                <CardDescription>Upload your DOCX, PPTX, and similarity report files</CardDescription>
              </CardHeader>
              <CardContent>
                {error && (
                  <Alert variant="destructive" className="mb-4">
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                {success && (
                  <Alert className="mb-4 border-green-200 bg-green-50">
                    <CheckCircle className="w-4 h-4" />
                    <AlertDescription className="text-green-800">{success}</AlertDescription>
                  </Alert>
                )}

                {latestSubmission &&
                  !latestSubmission.is_accepted &&
                  latestSubmission.similarity_percentage !== null && (
                    <Alert variant="destructive" className="mb-4">
                      <AlertDescription>
                        Your last submission had {latestSubmission.similarity_percentage}% similarity (above 10%
                        threshold). Please resubmit with improved content.
                      </AlertDescription>
                    </Alert>
                  )}

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="docx" className="flex items-center">
                      <FileText className="w-4 h-4 mr-2" />
                      DOCX File
                    </Label>
                    <Input
                      id="docx"
                      type="file"
                      accept=".docx"
                      onChange={(e) => setDocxFile(e.target.files?.[0] || null)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="pptx" className="flex items-center">
                      <Presentation className="w-4 h-4 mr-2" />
                      PPTX File
                    </Label>
                    <Input
                      id="pptx"
                      type="file"
                      accept=".pptx"
                      onChange={(e) => setPptxFile(e.target.files?.[0] || null)}
                      required
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="report" className="flex items-center">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Similarity Report (PDF/DOCX)
                    </Label>
                    <Input
                      id="report"
                      type="file"
                      accept=".pdf,.docx"
                      onChange={(e) => setReportFile(e.target.files?.[0] || null)}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full" disabled={uploading || !canSubmit}>
                    {uploading ? "Uploading..." : "Submit Files"}
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Submission History */}
            <Card>
              <CardHeader>
                <CardTitle>Submission History</CardTitle>
                <CardDescription>View all your previous submissions</CardDescription>
              </CardHeader>
              <CardContent>
                {loading ? (
                  <div className="text-center py-4">Loading...</div>
                ) : submissions.length === 0 ? (
                  <div className="text-center py-4 text-gray-500">No submissions yet</div>
                ) : (
                  <div className="space-y-4">
                    {submissions.map((submission) => (
                      <div key={submission.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="font-medium">Version {submission.version}</h3>
                            <p className="text-sm text-gray-500">{new Date(submission.created_at).toLocaleString()}</p>
                          </div>
                          {getStatusBadge(submission)}
                        </div>

                        {submission.similarity_percentage !== null && (
                          <div className="mb-2">
                            <p className="text-sm">
                              Similarity:{" "}
                              <span
                                className={`font-medium ${submission.similarity_percentage > 10 ? "text-red-600" : "text-green-600"}`}
                              >
                                {submission.similarity_percentage}%
                              </span>
                            </p>
                          </div>
                        )}

                        <div className="flex flex-wrap gap-2 text-xs">
                          <a
                            href={`http://localhost:8000${submission.docx_file}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            DOCX
                          </a>
                          <a
                            href={`http://localhost:8000${submission.pptx_file}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            PPTX
                          </a>
                          <a
                            href={`http://localhost:8000${submission.similarity_report}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            Report
                          </a>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

export default StudentDashboard
