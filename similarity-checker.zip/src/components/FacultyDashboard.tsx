"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useAuth } from "../contexts/AuthContext"
import api from "../services/api"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { LogOut, Users, FileText, CheckCircle, XCircle, Clock, Download } from "lucide-react"

interface Student {
  id: number
  username: string
  first_name: string
  last_name: string
}

interface Submission {
  id: number
  student: number
  student_name: string
  student_username: string
  docx_file: string
  pptx_file: string
  similarity_report: string
  similarity_percentage: number
  is_accepted: boolean
  version: number
  created_at: string
}

const FacultyDashboard: React.FC = () => {
  const { user, logout } = useAuth()
  const [students, setStudents] = useState<Student[]>([])
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [selectedStudent, setSelectedStudent] = useState<string>("all")
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    fetchStudents()
    fetchSubmissions()
  }, [])

  useEffect(() => {
    fetchSubmissions()
  }, [selectedStudent])

  const fetchStudents = async () => {
    try {
      const response = await api.get("/students/")
      setStudents(response.data)
    } catch (error) {
      console.error("Error fetching students:", error)
    }
  }

  const fetchSubmissions = async () => {
    setLoading(true)
    try {
      const url =
        selectedStudent === "all" ? "/submissions/faculty/" : `/submissions/faculty/?student_id=${selectedStudent}`
      const response = await api.get(url)
      setSubmissions(response.data)
    } catch (error) {
      console.error("Error fetching submissions:", error)
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (submission: Submission) => {
    if (submission.similarity_percentage === null) {
      return (
        <Badge variant="secondary">
          <Clock className="w-3 h-3 mr-1" />
          Processing
        </Badge>
      )
    }

    if (submission.is_accepted) {
      return (
        <Badge variant="default" className="bg-green-500">
          <CheckCircle className="w-3 h-3 mr-1" />
          Accepted
        </Badge>
      )
    } else {
      return (
        <Badge variant="destructive">
          <XCircle className="w-3 h-3 mr-1" />
          Rejected
        </Badge>
      )
    }
  }

  const groupedSubmissions = submissions.reduce(
    (acc, submission) => {
      const key = submission.student_username
      if (!acc[key]) {
        acc[key] = []
      }
      acc[key].push(submission)
      return acc
    },
    {} as Record<string, Submission[]>,
  )

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Faculty Dashboard</h1>
              <p className="text-gray-600">
                Welcome, {user?.first_name} {user?.last_name}
              </p>
            </div>
            <Button onClick={logout} variant="outline">
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          {/* Filters */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Student Submissions
              </CardTitle>
              <CardDescription>View and manage all student submissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <div className="flex-1">
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by student" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Students</SelectItem>
                      {students.map((student) => (
                        <SelectItem key={student.id} value={student.id.toString()}>
                          {student.first_name} {student.last_name} ({student.username})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={fetchSubmissions} disabled={loading}>
                  {loading ? "Loading..." : "Refresh"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Submissions */}
          {loading ? (
            <div className="text-center py-8">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading submissions...</p>
            </div>
          ) : Object.keys(groupedSubmissions).length === 0 ? (
            <Card>
              <CardContent className="text-center py-8">
                <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No submissions found</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {Object.entries(groupedSubmissions).map(([studentUsername, studentSubmissions]) => {
                const student = studentSubmissions[0]
                return (
                  <Card key={studentUsername}>
                    <CardHeader>
                      <CardTitle className="flex items-center justify-between">
                        <span>
                          {student.student_name} ({student.student_username})
                        </span>
                        <Badge variant="outline">
                          {studentSubmissions.length} submission{studentSubmissions.length !== 1 ? "s" : ""}
                        </Badge>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {studentSubmissions.map((submission) => (
                          <div key={submission.id} className="border rounded-lg p-4 bg-gray-50">
                            <div className="flex justify-between items-start mb-3">
                              <div>
                                <h4 className="font-medium">Version {submission.version}</h4>
                                <p className="text-sm text-gray-500">
                                  Submitted: {new Date(submission.created_at).toLocaleString()}
                                </p>
                              </div>
                              {getStatusBadge(submission)}
                            </div>

                            {submission.similarity_percentage !== null && (
                              <div className="mb-3">
                                <div className="flex items-center space-x-2">
                                  <span className="text-sm font-medium">Similarity:</span>
                                  <span
                                    className={`text-sm font-bold ${
                                      submission.similarity_percentage > 10 ? "text-red-600" : "text-green-600"
                                    }`}
                                  >
                                    {submission.similarity_percentage}%
                                  </span>
                                  {submission.similarity_percentage > 10 && (
                                    <Badge variant="destructive" className="text-xs">
                                      Above Threshold
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            )}

                            <div className="flex flex-wrap gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => window.open(`http://localhost:8000${submission.docx_file}`, "_blank")}
                              >
                                <Download className="w-3 h-3 mr-1" />
                                DOCX
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => window.open(`http://localhost:8000${submission.pptx_file}`, "_blank")}
                              >
                                <Download className="w-3 h-3 mr-1" />
                                PPTX
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() =>
                                  window.open(`http://localhost:8000${submission.similarity_report}`, "_blank")
                                }
                              >
                                <Download className="w-3 h-3 mr-1" />
                                Report
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

export default FacultyDashboard
