import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'similarity_checker.settings')
django.setup()

from submissions.models import User

# Create demo users
def create_demo_users():
    # Create faculty user
    if not User.objects.filter(username='faculty1').exists():
        faculty = User.objects.create_user(
            username='faculty1',
            password='faculty123',
            email='faculty@example.com',
            first_name='John',
            last_name='Professor',
            role='faculty'
        )
        print(f"Created faculty user: {faculty.username}")
    
    # Create student users
    students_data = [
        {
            'username': 'student1',
            'password': 'student123',
            'email': 'student1@example.com',
            'first_name': 'Alice',
            'last_name': 'Smith'
        },
        {
            'username': 'student2',
            'password': 'student123',
            'email': 'student2@example.com',
            'first_name': 'Bob',
            'last_name': 'Johnson'
        }
    ]
    
    for student_data in students_data:
        if not User.objects.filter(username=student_data['username']).exists():
            student = User.objects.create_user(
                username=student_data['username'],
                password=student_data['password'],
                email=student_data['email'],
                first_name=student_data['first_name'],
                last_name=student_data['last_name'],
                role='student'
            )
            print(f"Created student user: {student.username}")

if __name__ == '__main__':
    create_demo_users()
    print("\nDemo users created successfully!")
    print("\nLogin credentials:")
    print("Faculty: username=faculty1, password=faculty123")
    print("Student 1: username=student1, password=student123")
    print("Student 2: username=student2, password=student123")
