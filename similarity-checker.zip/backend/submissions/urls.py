from django.urls import path
from . import views

urlpatterns = [
    path('auth/login/', views.login_view, name='login'),
    path('auth/logout/', views.logout_view, name='logout'),
    path('auth/profile/', views.profile_view, name='profile'),
    
    path('submissions/create/', views.SubmissionCreateView.as_view(), name='submission-create'),
    path('submissions/student/', views.StudentSubmissionsView.as_view(), name='student-submissions'),
    path('submissions/faculty/', views.FacultySubmissionsView.as_view(), name='faculty-submissions'),
    path('students/', views.students_list_view, name='students-list'),
]
