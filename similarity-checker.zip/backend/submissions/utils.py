import re
import os
from docx import Document
import PyPDF2

def extract_similarity_percentage(file_path):
    """
    Extract similarity percentage from uploaded similarity report.
    Supports both PDF and DOCX formats.
    """
    file_extension = os.path.splitext(file_path)[1].lower()
    
    try:
        if file_extension == '.pdf':
            return extract_from_pdf(file_path)
        elif file_extension == '.docx':
            return extract_from_docx(file_path)
        else:
            # Try to read as text file
            return extract_from_text(file_path)
    except Exception as e:
        print(f"Error extracting similarity: {e}")
        return 0.0

def extract_from_pdf(file_path):
    """Extract similarity percentage from PDF file."""
    try:
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            text = ""
            for page in pdf_reader.pages:
                text += page.extract_text()
        
        return find_similarity_percentage(text)
    except Exception as e:
        print(f"Error reading PDF: {e}")
        return 0.0

def extract_from_docx(file_path):
    """Extract similarity percentage from DOCX file."""
    try:
        doc = Document(file_path)
        text = ""
        for paragraph in doc.paragraphs:
            text += paragraph.text + "\n"
        
        return find_similarity_percentage(text)
    except Exception as e:
        print(f"Error reading DOCX: {e}")
        return 0.0

def extract_from_text(file_path):
    """Extract similarity percentage from text file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            text = file.read()
        
        return find_similarity_percentage(text)
    except Exception as e:
        print(f"Error reading text file: {e}")
        return 0.0

def find_similarity_percentage(text):
    """
    Find similarity percentage in text using regex patterns.
    Common patterns in similarity reports.
    """
    # Common patterns for similarity percentage
    patterns = [
        r'similarity[:\s]*(\d+(?:\.\d+)?)%',
        r'(\d+(?:\.\d+)?)%\s*similarity',
        r'overall\s*similarity[:\s]*(\d+(?:\.\d+)?)%',
        r'plagiarism[:\s]*(\d+(?:\.\d+)?)%',
        r'(\d+(?:\.\d+)?)%\s*plagiarism',
        r'match[:\s]*(\d+(?:\.\d+)?)%',
        r'(\d+(?:\.\d+)?)%\s*match',
        r'duplicate[:\s]*(\d+(?:\.\d+)?)%',
        r'(\d+(?:\.\d+)?)%\s*duplicate',
    ]
    
    text_lower = text.lower()
    
    for pattern in patterns:
        matches = re.findall(pattern, text_lower, re.IGNORECASE)
        if matches:
            try:
                # Return the first valid percentage found
                percentage = float(matches[0])
                if 0 <= percentage <= 100:
                    return percentage
            except ValueError:
                continue
    
    # If no pattern matches, look for any percentage that might be similarity
    # This is a fallback for unusual formats
    percentage_matches = re.findall(r'(\d+(?:\.\d+)?)%', text)
    if percentage_matches:
        for match in percentage_matches:
            try:
                percentage = float(match)
                if 0 <= percentage <= 100:
                    # Check if it's in a context that suggests similarity
                    match_index = text.find(f"{match}%")
                    context = text[max(0, match_index-50):match_index+50].lower()
                    
                    similarity_keywords = ['similar', 'match', 'plagiar', 'duplicate', 'copy']
                    if any(keyword in context for keyword in similarity_keywords):
                        return percentage
            except ValueError:
                continue
    
    return 0.0
