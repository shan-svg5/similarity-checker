import re
import os
from rest_framework import status, generics, permissions
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import RefreshToken
from django.contrib.auth import authenticate
from .models import User, Submission
from .serializers import UserSerializer, LoginSerializer, SubmissionSerializer, SubmissionCreateSerializer
from .utils import extract_similarity_percentage

class IsStudent(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'student'

class IsFaculty(permissions.BasePermission):
    def has_permission(self, request, view):
        return request.user.is_authenticated and request.user.role == 'faculty'

@api_view(['POST'])
@permission_classes([permissions.AllowAny])
def login_view(request):
    serializer = LoginSerializer(data=request.data)
    if serializer.is_valid():
        user = serializer.validated_data['user']
        refresh = RefreshToken.for_user(user)
        
        return Response({
            'refresh': str(refresh),
            'access': str(refresh.access_token),
            'user': UserSerializer(user).data
        })
    
    return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

@api_view(['POST'])
@permission_classes([permissions.IsAuthenticated])
def logout_view(request):
    try:
        refresh_token = request.data["refresh"]
        token = RefreshToken(refresh_token)
        token.blacklist()
        return Response({'message': 'Successfully logged out'})
    except Exception as e:
        return Response({'error': 'Invalid token'}, status=status.HTTP_400_BAD_REQUEST)

@api_view(['GET'])
@permission_classes([permissions.IsAuthenticated])
def profile_view(request):
    return Response(UserSerializer(request.user).data)

class SubmissionCreateView(generics.CreateAPIView):
    serializer_class = SubmissionCreateSerializer
    permission_classes = [IsStudent]
    
    def perform_create(self, serializer):
        submission = serializer.save()
        
        # Extract similarity percentage from the uploaded report
        try:
            similarity_percentage = extract_similarity_percentage(submission.similarity_report.path)
            submission.similarity_percentage = similarity_percentage
            submission.save()
        except Exception as e:
            print(f"Error extracting similarity: {e}")
            submission.similarity_percentage = 0.0
            submission.save()

class StudentSubmissionsView(generics.ListAPIView):
    serializer_class = SubmissionSerializer
    permission_classes = [IsStudent]
    
    def get_queryset(self):
        return Submission.objects.filter(student=self.request.user)

class FacultySubmissionsView(generics.ListAPIView):
    serializer_class = SubmissionSerializer
    permission_classes = [IsFaculty]
    queryset = Submission.objects.all()
    
    def get_queryset(self):
        queryset = Submission.objects.all().select_related('student')
        student_id = self.request.query_params.get('student_id')
        if student_id:
            queryset = queryset.filter(student_id=student_id)
        return queryset

@api_view(['GET'])
@permission_classes([IsFaculty])
def students_list_view(request):
    students = User.objects.filter(role='student')
    return Response(UserSerializer(students, many=True).data)
