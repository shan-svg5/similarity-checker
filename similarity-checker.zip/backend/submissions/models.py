from django.contrib.auth.models import AbstractUser
from django.db import models
import os

class User(AbstractUser):
    ROLE_CHOICES = [
        ('student', 'Student'),
        ('faculty', 'Faculty'),
    ]
    role = models.CharField(max_length=10, choices=ROLE_CHOICES, default='student')
    
    def __str__(self):
        return f"{self.username} ({self.role})"

class Submission(models.Model):
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='submissions')
    docx_file = models.FileField(upload_to='submissions/docx/')
    pptx_file = models.FileField(upload_to='submissions/pptx/')
    similarity_report = models.FileField(upload_to='submissions/reports/')
    similarity_percentage = models.FloatField(null=True, blank=True)
    is_accepted = models.BooleanField(default=False)
    version = models.IntegerField(default=1)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.student.username} - Version {self.version} ({self.similarity_percentage}%)"
    
    def save(self, *args, **kwargs):
        if not self.pk:  # New submission
            # Get the latest version for this student
            latest = Submission.objects.filter(student=self.student).order_by('-version').first()
            if latest:
                self.version = latest.version + 1
        
        # Check if similarity is acceptable
        if self.similarity_percentage is not None:
            self.is_accepted = self.similarity_percentage <= 10.0
        
        super().save(*args, **kwargs)
